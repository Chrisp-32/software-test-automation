/**
 * 
 */
/**
 * 
 */
module Project_1 {
    requires org.junit.jupiter.api;

}