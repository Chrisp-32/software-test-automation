package taskservice;

public class Task {
	 private final String taskId;
	    private String name;
	    private String description;

	    // Constructor enforces constraints on initialization
	    public Task(String taskId, String name, String description) {
	        if (taskId == null || taskId.length() > 10) {
	            throw new IllegalArgumentException("Invalid task ID: Must not be null and max 10 characters.");
	        }
	        this.taskId = taskId;
	        
	        // Use setters to reuse input validation logic
	        setName(name);
	        setDescription(description);
	    }

	    // Task ID is only readable, fulfilling the non-updatable requirement
	    public String getTaskId() {
	        return taskId;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        if (name == null || name.length() > 20) {
	            throw new IllegalArgumentException("Invalid name: Must not be null and max 20 characters.");
	        }
	        this.name = name;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        if (description == null || description.length() > 50) {
	            throw new IllegalArgumentException("Invalid description: Must not be null and max 50 characters.");
	        }
	        this.description = description;
	    }
}
