package contactsevice;

public class Contact {
private final String contactId;
private String firstname;
private String lastname;
private String phone;
private String address;




public Contact(String contactId, String firstname, String lastname, String phone, String address) {
	if (contactId == null || contactId.length() > 10) {
		throw new IllegalArgumentException("Invalid Contact ID");
	}
	if (firstname == null || contactId.length() > 10) {
		throw new IllegalArgumentException("Invalid first name");
	}
	if (lastname == null || contactId.length() > 10) {
		throw new IllegalArgumentException("Invalid last name");
	}
	if (phone == null || contactId.length() > 10) {
		throw new IllegalArgumentException("Invalid phone number");
	}
	if (address == null || contactId.length() > 10) {
		throw new IllegalArgumentException("Invalid address");
	}

	this.contactId = contactId;
	this.firstname = firstname;
	this.lastname = lastname;
	this.phone = phone;
	this.address = address;
	
}

public String getContactId() { return contactId; }
public String getFirstName() { return firstname; }
public String getLastName() { return lastname; }
public String getPhone() { return phone; }
public String getAddress() { return address; }

public void setFirstName(String firstname) {
    if (firstname == null || firstname.length() > 10) {
        throw new IllegalArgumentException("Invalid first name: Must be non-null and up to 10 characters.");
    }
    this.firstname = firstname;
}

public void setLastName(String lastname) {
    if (lastname == null || lastname.length() > 10) {
        throw new IllegalArgumentException("Invalid last name: Must be non-null and up to 10 characters.");
    }
    this.lastname = lastname;
}

public void setPhone(String phone) {
    if (phone == null || !phone.matches("\\d{10}")) {
        throw new IllegalArgumentException("Invalid phone number: Must be non-null and exactly 10 digits.");
    }
    this.phone = phone;
}

public void setAddress(String address) {
    if (address == null || address.length() > 30) {
        throw new IllegalArgumentException("Invalid address: Must be non-null and up to 30 characters.");
    }
    this.address = address;
}

}
