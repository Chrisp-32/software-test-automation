package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import taskservice.Task;
import taskservice.TaskService;
import org.junit.jupiter.api.BeforeEach;
public class TaskServiceTest {
    private TaskService service;

    @BeforeEach
    public void setUp() {
        service = new TaskService();
    }

    @Test
    public void testAddTaskSuccess() {
        Task task = new Task("1", "Name", "Description");
        service.addTask(task);
        
        assertNotNull(service.getTask("1"));
        assertEquals("Name", service.getTask("1").getName());
    }

    @Test
    public void testAddDuplicateTaskIdFails() {
        Task task1 = new Task("1", "First Task", "Description");
        Task task2 = new Task("1", "Second Task", "Different Description");
        
        service.addTask(task1);
        
        // Adding second task with identical ID must throw an exception
        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    public void testDeleteTaskSuccess() {
        Task task = new Task("1", "Name", "Description");
        service.addTask(task);
        
        service.deleteTask("1");
        assertNull(service.getTask("1"));
    }

    @Test
    public void testDeleteNonExistentTaskFails() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("999");
        });
    }

    @Test
    public void testUpdateTaskFieldsSuccess() {
        Task task = new Task("1", "Old Name", "Old Description");
        service.addTask(task);
        
        service.updateTaskName("1", "New Name");
        service.updateTaskDescription("1", "New Description");
        
        assertEquals("New Name", service.getTask("1").getName());
        assertEquals("New Description", service.getTask("1").getDescription());
    }

    @Test
    public void testUpdateNonExistentTaskFails() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("999", "New Name");
        });
        
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescription("999", "New Description");
        });
    }
}