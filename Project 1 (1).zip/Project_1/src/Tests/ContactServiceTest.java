package Tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import contactsevice.Contact;
import contactsevice.ContactService;

import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
	private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddContactSuccess() {
        Contact contact = new Contact("C1", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        
        Contact retrieved = service.getContact("C1");
        assertNotNull(retrieved);
        assertEquals("John", retrieved.getFirstName());
    }

    @Test
    public void testAddDuplicateContactIdFails() {
        Contact contact1 = new Contact("C1", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("C1", "Jane", "Smith", "0987654321", "456 Oak St");
        
        service.addContact(contact1);
        
        // Ensure adding a contact with a duplicate ID throws an exception
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact2));
    }

    @Test
    public void testDeleteContactSuccess() {
        Contact contact = new Contact("C1", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        
        service.deleteContact("C1");
        assertNull(service.getContact("C1"));
    }

    @Test
    public void testDeleteNonExistentContactFails() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("NonExistentID"));
    }

    @Test
    public void testUpdateContactFieldsSuccess() {
        Contact contact = new Contact("C1", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        
        // Perform standard updates to all allowable fields
        service.updateContactFields("C1", "Jane", "Smith", "0987654321", "456 Oak St");
        
        Contact updated = service.getContact("C1");
        assertEquals("Jane", updated.getFirstName());
        assertEquals("Smith", updated.getLastName());
        assertEquals("0987654321", updated.getPhone());
        assertEquals("456 Oak St", updated.getAddress());
        // Verify ID remains exactly what it was
        assertEquals("C1", updated.getContactId());
    }

    @Test
    public void testUpdateNonExistentContactFails() {
        assertThrows(IllegalArgumentException.class, () -> 
            service.updateContactFields("FakeID", "Jane", "Smith", "0987654321", "456 Oak St"));
    }

    @Test
    public void testUpdateWithInvalidFieldsFails() {
        Contact contact = new Contact("C1", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);

        // This operation must fail because the phone field length rule is violated (too long)
        assertThrows(IllegalArgumentException.class, () -> 
            service.updateContactFields("C1", "John", "Doe", "123456789012345", "123 Main St"));
    }
}
