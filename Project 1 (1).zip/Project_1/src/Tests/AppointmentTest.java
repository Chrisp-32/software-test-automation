package Tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import appointmentservice.Appointment;

class AppointmentTest {

    private Date futureDate;

    @BeforeEach
    void setUp() {
        // Create a guaranteed future date (tomorrow)
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        futureDate = cal.getTime();
    }

    @Test
    void testValidAppointmentCreation() {
        Appointment appointment = new Appointment("1234567890", futureDate, "Valid Description");
        assertNotNull(appointment);
        assertEquals("1234567890", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Valid Description", appointment.getDescription());
    }

    @Test
    void testAppointmentIdValidation() {
        // Test Null ID
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment(null, futureDate, "Description")
        );

        // Test ID too long (> 10 characters)
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("12345678901", futureDate, "Description")
        );
    }

    @Test
    void testAppointmentDateValidation() {
        // Test Null Date
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("123", null, "Description")
        );

        // Test Past Date
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1);
        Date pastDate = cal.getTime();

        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("123", pastDate, "Description")
        );
    }

    @Test
    void testDescriptionValidation() {
        // Test Null Description
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("123", futureDate, null)
        );

        // Test Description too long (> 50 characters)
        String longDescription = "This description is explicitly designed to be longer than fifty characters.";
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("123", futureDate, longDescription)
        );
    }
}