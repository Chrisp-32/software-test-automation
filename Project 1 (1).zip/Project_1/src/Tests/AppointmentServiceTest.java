package Tests;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import appointmentservice.Appointment;
import appointmentservice.AppointmentService;

class AppointmentServiceTest {

    private AppointmentService appointmentService;
    private Date validFutureDate;

    @BeforeEach
    void setUp() {
        appointmentService = new AppointmentService();
        // Create a clear future date (1 hour from now) 
        validFutureDate = new Date(System.currentTimeMillis() + 3600000);
    }

    @Test
    void testAddAppointmentSuccess() {
        Appointment appointment = new Appointment("A123", validFutureDate, "Dentist checkup");
        appointmentService.addAppointment(appointment);
        
        // Verify the appointment was added correctly
        assertNotNull(appointmentService.getAppointment("A123"));
        assertEquals("A123", appointmentService.getAppointment("A123").getAppointmentId());
    }

    @Test
    void testAddAppointmentNullThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(null);
        });
    }

    @Test
    void testAddDuplicateAppointmentIdThrowsException() {
        Appointment appointment1 = new Appointment("A123", validFutureDate, "Dentist checkup");
        Appointment appointment2 = new Appointment("A123", validFutureDate, "Therapy session");
        
        appointmentService.addAppointment(appointment1);
        
        // Attempting to add an appointment with the same ID  throws an exception
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(appointment2);
        });
    }

    @Test
    void testDeleteAppointmentSuccess() {
        Appointment appointment = new Appointment("A123", validFutureDate, "Dentist checkup");
        appointmentService.addAppointment(appointment);
        
        // Ensure it is there before deleting
        assertNotNull(appointmentService.getAppointment("A123"));
        
        // Delete and verify it is gone
        appointmentService.deleteAppointment("A123");
        assertNull(appointmentService.getAppointment("A123"));
    }

    @Test
    void testDeleteNonExistentAppointmentIdThrowsException() {
        // Attempting to delete an ID that doesn't exist throws an exception
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("NONEXISTENT");
        });
    }
}