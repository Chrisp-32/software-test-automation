package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import taskservice.Task;

public class TaskTest {

    @Test
    public void testTaskCreationSuccess() {
        Task task = new Task("12345", "Task Name", "This is a brief task description.");
        assertEquals("12345", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("This is a brief task description.", task.getDescription());
    }

    @Test
    public void testTaskIdConstraints() {
        // Assert fail if null
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Description");
        });
        
        // Assert fail if longer than 10 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Description");
        });
    }

    @Test
    public void testTaskNameConstraints() {
        // Assert fail if null
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", null, "Description");
        });
        
        // Assert fail if longer than 20 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "This name is definitely way too long", "Description");
        });
    }

    @Test
    public void testTaskDescriptionConstraints() {
        // Assert fail if null
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "Name", null);
        });
        
        // Assert fail if longer than 50 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", "Name", "This specific description field is far too long because it exceeds fifty characters.");
        });
    }

    @Test
    public void testTaskSettersValidUpdates() {
        Task task = new Task("1", "Name", "Description");
        task.setName("Updated Name");
        task.setDescription("Updated Description");
        
        assertEquals("Updated Name", task.getName());
        assertEquals("Updated Description", task.getDescription());
    }
}