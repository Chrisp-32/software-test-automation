package appointmentservice;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    // In-memory data structure to hold appointments
    private final Map<String, Appointment> appointments = new HashMap<>();

    // Adds an appointment if the ID is unique
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null.");
        }
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists.");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    // Deletes an appointment by its ID
    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found.");
        }
        appointments.remove(appointmentId);
    }

    // Getter method strictly for JUnit verification purposes
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}